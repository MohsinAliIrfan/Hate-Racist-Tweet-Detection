print("hello world")

import streamlit as st
import pickle
import re
import string
from nltk.corpus import stopwords
import numpy as np



def test_user_input(new_user_input, logreg_model, random_forest_model, decision_trees_model, xgb_model):

    print("NEW USER INPUT", new_user_input)

    with open('tweets_vectotrzier.pkl', 'rb') as file:
        new_tweets_vectotrizer = pickle.load(file)

    temp = new_tweets_vectotrizer.transform(new_user_input)

    print("ANOTHER USER INPUT", new_user_input)

    # tweets_vectorizer.transform(new_user_input)

    log_reg_sentiment = logreg_model.predict(temp)
    random_forest_model_sentiment = random_forest_model.predict(temp)
    decision_trees_model_sentiment = decision_trees_model.predict(temp)
    xgb_model_sentiment = xgb_model.predict(temp)

    st.write("LOGISTIC REGRESSION", log_reg_sentiment)
    st.write("RANDOM FOREST CLASSIFIER ", random_forest_model_sentiment)
    st.write("DECISION_TREES_CLASSIFIER", decision_trees_model_sentiment)
    st.write("XGB CLASSIFIER", xgb_model_sentiment)
    


    # if sentiment.any == 1:
    #     st.write("RACIST BEHAVIOR")
    # else:
    #     st.write("NO RACIST BEHAVIOR")



def cleaning_user_input(user_input):
    user_input = str(user_input).lower()
    user_input = re.sub('RT | rt | @\w+', '', user_input)
    user_input = re.sub('\[.*?\]', '', user_input)
    user_input = re.sub('https?://\S+|www\.\S+', '', user_input)
    user_input = re.sub('<.*?>+', '', user_input)
    user_input = re.sub('[%s]' % re.escape(string.punctuation), '', user_input)
    user_input = re.sub('\n', '', user_input)
    user_input = re.sub('\w*\d\w*', '', user_input)
   
    user_input = list(word for word in user_input.split() if word not in (stopwords.words("english")))
    print("USER INPUT " , user_input)
    return user_input


def main():
    st.title("RACIST TWEETS DETECTION", "hello")
    user_input = st.text_input("Enter Tweet")
    # user_input = cleaning_user_input(user_input)

    # loading models
    logreg_model = pickle.load(open("D:/FINAL YEAR PROJECT/Logreg.pkl", "rb"))
    random_forest_model = pickle.load(open("D:/FINAL YEAR PROJECT/ranfor.pkl", "rb"))
    decision_trees_model = pickle.load(open("D:/FINAL YEAR PROJECT/dectree.pkl", "rb"))
    xgb_model = pickle.load(open("D:/FINAL YEAR PROJECT/xgb.pkl", "rb"))
    if st.button("Check"):
        new_user_input = cleaning_user_input(user_input)

        # print("TYPE" , type(new_user_input))
        test_user_input(new_user_input, logreg_model, random_forest_model, decision_trees_model, xgb_model)
    


main()


